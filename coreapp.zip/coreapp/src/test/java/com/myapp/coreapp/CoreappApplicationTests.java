package com.myapp.coreapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoreappApplicationTests {

	@Test
	void contextLoads() {
	}

}
