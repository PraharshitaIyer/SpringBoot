package com.myapp.coreapp.mybean;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Scope("prototype")
@Component
public class Address {
	public Address() {
		super();
		System.out.println("Address bean intialized......");
	}

}
