package com.myapp.coreapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class CoreappApplication {

	public static void main(String[] args) {
		//SpringApplication.run(CoreappApplication.class, args);
		
		 AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		   
		    ctx.register(AppConfing.class);

		       ctx.refresh();

	}

}
