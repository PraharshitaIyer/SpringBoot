package com.myapp.coreapp.mybean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Student {
	@Autowired
	private Address stAddress;

	public Address getStAddress() {
		return stAddress;
	}

	public void setStAddress(Address stAddress) {
		this.stAddress = stAddress;
	}

	public Student(Address stAddress) {
		
		super();
		this.stAddress= stAddress;
		System.out.println("Student bean initialized.........");
	}
	

}
