package com.example.service;

import com.example.model.Cart;

public interface CartService {

    Cart getCartById(int cartId);

    void update(Cart cart);
}
