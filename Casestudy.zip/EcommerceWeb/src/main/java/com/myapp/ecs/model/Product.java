package com.myapp.ecs.model;

import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pc_pro")
public class Product {
	 @Id 
	 @Column(name="id")
	 private int ProductId;
		
	 private String name;
     private double Price;
     private String brand;
     private String code;
     private int quantity;
     
     public Product() {
    	 this.ProductId=new Random().nextInt(100000);
     }

	public Product(String name,int quantity,String brand, double price,String code ) {
		this.ProductId=new Random().nextInt(100000);
		this.name = name;
		this.quantity= quantity;
		this.brand= brand ;
		this.code = code;
		this.Price = price;
	}

	public int getProductId() {
		return ProductId;
	}

	public void setProductId(int productId) {
		ProductId = productId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return Price;
	}

	public void setPrice(double price) {
		Price = price;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	@Override
	public String toString() {
		return "Employee [ProductId=" + ProductId + ", name=" + name + ", brand=" + brand + ", quantity=" + quantity+ ", code=" + code + ", Price=" + Price+ "]";
	}
	}
