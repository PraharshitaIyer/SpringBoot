package com.myapp.ecs.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;


import com.myapp.ecs.model.Customer;
import com.myapp.ecs.service.CustomerService;

@RequestMapping("/customers") // is common to all the mapping methods
@RestController //(@Controller+@ResponseBody)
public class EcsRestController {
	
	@Qualifier("esi1")
	@Autowired
	private CustomerService customerService;

	public EcsRestController() {
		System.out.println("EcsRestController created...");
	}
	@GetMapping
	public List<Customer> getAllCustomers() {
		System.out.println("In get allCustomerss");
		return customerService.findAllCustomers();
	}
	@GetMapping("/{customerId}")
	public Customer getCustomer(@PathVariable("customerId") int customerId) {
		System.out.println("In get Customer " + customerId);
		return customerService.findCustomer(customerId);
	}

	@DeleteMapping("/{customerId}")
	public List<Customer> deleteCustomer(@PathVariable("customerId") int customerId) {
		System.out.println("In delete Customer " + customerId);
		customerService.deleteCustomer(customerId);
		return customerService.findAllCustomers();
	}
	
	@PutMapping("/{customerId}")
	public List<Customer> updateCustomer(@PathVariable("customerId") int customerId,@RequestBody Customer customer) {
		System.out.println("In update Customer " + customer);
		customerService.updateCustomer(customer);
		return customerService.findAllCustomers();
	}
	/*
	 * http://localhost:1212/ems-spring-v1/customers
	{
		"email":"abc@gmail.com",
		"fname":"abc",
		"iname":"res",
		"mobile":"475554",
		"Address":"gjbhkjnhb",
		"Total":876876
		}*/
	@PostMapping
	public List<Customer> addCustomer(@RequestBody Customer customer) {
		System.out.println("In add Customer " + customer);
		customerService.addCustomer(customer);
		return customerService.findAllCustomers();
	}	
	
}

