package com.myapp.ecs.reposiotry;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.myapp.ecs.model.Customer;

@Repository
public interface CustomerJPARepository extends JpaRepository<Customer, Integer> {

}
